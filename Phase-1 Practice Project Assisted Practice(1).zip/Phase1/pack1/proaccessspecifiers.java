package pack1;

public class proaccessspecifiers {

	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
	
	public class pubaccessspecifiers {

		public void display() 
	    { 
	        System.out.println("This is Public Access Specifiers"); 
	    } 
	}

}