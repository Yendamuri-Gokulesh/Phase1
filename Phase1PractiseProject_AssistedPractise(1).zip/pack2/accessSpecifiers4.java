package pack2;

import pack1.*;
public class accessSpecifiers4 {

	public static void main(String[] args) {
		
		accessSpecifiers4 obj = new accessSpecifiers4(); 
        obj.display();  
		

	}
	private void display() {
		System.out.println(" This is Public AccessSpecifier ");
	}

	
}
